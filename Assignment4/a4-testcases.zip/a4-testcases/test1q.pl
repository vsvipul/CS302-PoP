q1 :- escapes(o1), write(true), nl.
q2 :- escapesthrough(o1, m1), write(true), nl.
q3 :- allescapes(m1, L), write(L), nl.
