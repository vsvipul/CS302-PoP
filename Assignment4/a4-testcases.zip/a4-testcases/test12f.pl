alloc(z, o201).
alloc(z, o202).
copy(y, z).
store(z, v, o202).
load(x, z, v).
invoke(w, [x]).

alloc(a, o1). 
store(a, f, a).
alloc(b, o2).
copy(c, b).
store(c, f, b).
alloc(d, o3).
load(d, c, f).
invoke(n1, [a,d]).
invoke(n2, [c]).

