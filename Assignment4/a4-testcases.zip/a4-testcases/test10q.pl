q1 :- allescapes(m1, L), write(L), nl.
q2 :- escapes(o1), write(true), nl.
q3 :- escapes(o2), write(true), nl.
q4 :- escapes(o3), write(true), nl.
