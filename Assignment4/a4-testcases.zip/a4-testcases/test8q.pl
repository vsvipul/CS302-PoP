q1 :- allescapes(m10, L), write(L), nl.
q2 :- allescapes(m12, L), write(L), nl.
q3 :- escapes(o1), write(true), nl.
q4 :- escapes(o2), write(true), nl.
q5 :- escapes(o3), write(true), nl.
