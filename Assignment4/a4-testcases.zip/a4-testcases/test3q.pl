q1 :- escapes(o1), write(true), nl.
q2 :- escapes(o3), write(true), nl.
q3 :- allescapes(m1, L), write(L), nl.
