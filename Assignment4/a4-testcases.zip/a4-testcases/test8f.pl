alloc(z, o201).
alloc(z, o202).
copy(y, z).
store(z, v, o202).
load(x, z, v).
invoke(w, [x]).

invoke(m10, [a]).
alloc(a, o1).
invoke(m12, [c]).
alloc(a, o2).
alloc(c, o3).
store(c, h, a).

