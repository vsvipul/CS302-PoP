q1 :- escapesthrough(o1, m1), write(true), nl.
q2 :- escapesthrough(o1, m2), write(true), nl.
q3 :- escapesthrough(o2, m1), write(true), nl.
q4 :- escapesthrough(o2, m2), write(true), nl.
q5 :- allescapes(m1, L), write(L), nl.
q6 :- allescapes(m2, L), write(L), nl.
q7 :- escapes(o3), write(L), nl.
