q1 :- allescapes(n1, L), write(L), nl.
q2 :- allescapes(n2, L), write(L), nl.
q3 :- escapes(o1), write(true), nl.
q4 :- escapes(o2), write(true), nl.
q5 :- escapes(o3), write(true), nl.
q6 :- escapesthrough(o3, n2), write(true), nl.
q7 :- escapesthrough(o3, n1), write(true), nl.
