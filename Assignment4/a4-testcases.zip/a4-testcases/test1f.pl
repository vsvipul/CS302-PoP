alloc(z, o201).
alloc(z, o202).
copy(y, z).
store(z, v, o202).
load(x, z, v).
invoke(w, [x]).

alloc(a, o1).
invoke(m1, [a]).

