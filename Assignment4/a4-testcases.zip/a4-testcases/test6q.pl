q1 :- escapes(o1), write(true), nl.
