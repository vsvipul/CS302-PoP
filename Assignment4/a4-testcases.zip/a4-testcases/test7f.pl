alloc(z, o201).
alloc(z, o202).
copy(y, z).
store(z, v, o202).
load(x, z, v).
invoke(w, [x]).

alloc(a, o1).
alloc(b, o2).
alloc(c, o3).
alloc(d, o4).
copy(a, b).
copy(b, c).
copy(c, a).
invoke(m1, [a]).

